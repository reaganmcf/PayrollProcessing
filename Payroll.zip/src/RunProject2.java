/**
 * RunProject2 is the generic runner that will start the entire project. No
 * logic is done in here, just an entry point via the main()
 * 
 * @author Reagan McFarland, Vatche Kafafian
 */
public class RunProject2 {
    public static void main(String[] args) {
        new PayrollProcessing().run();
    }
}